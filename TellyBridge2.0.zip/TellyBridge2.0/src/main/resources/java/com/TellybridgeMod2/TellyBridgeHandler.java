package com.tellybridge;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class TellyBridgeHandler {
    public boolean active = false;
    public int bindKey = Keyboard.KEY_NONE;
    public int delay = 1000; // ms
    public long lastAction = 0;

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent e) {
        if (bindKey != Keyboard.KEY_NONE && Keyboard.isKeyDown(bindKey)) {
            active = !active;
            System.out.println("TellyBridge " + (active ? "Aktif" : "Pasif"));
        }

        if (active) {
            long now = System.currentTimeMillis();
            if (now - lastAction >= delay) {
                doTellyBridge();
                lastAction = now;
            }
        }
    }

    private void doTellyBridge() {
        // Buraya hareket + blok koyma mantığı gelecek.
        System.out.println("Telly Bridge hareketi çalıştı!");
    }
}