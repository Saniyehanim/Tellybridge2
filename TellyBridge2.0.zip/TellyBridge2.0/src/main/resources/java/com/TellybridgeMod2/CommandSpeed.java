package com.tellybridge;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class CommandSpeed extends CommandBase {
    @Override
    public String getCommandName() { return "speed"; }
    @Override
    public String getCommandUsage(ICommandSender sender) { return "/speed <değer>"; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Kullanım: /speed <değer>"));
            return;
        }

        try {
            int level = Integer.parseInt(args[0]);
            if (level < 0) {
                sender.addChatMessage(new net.minecraft.util.ChatComponentText("Negatif hız olamaz!"));
                return;
            }

            TellyBridgeMod.handler.mc.thePlayer.addPotionEffect(
                new PotionEffect(Potion.moveSpeed.id, 999999, level, false, false)
            );
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Hız ayarlandı: " + level));
        } catch (NumberFormatException e) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Geçersiz sayı!"));
        }
    }

    @Override
    public int getRequiredPermissionLevel() { return 0; }
}