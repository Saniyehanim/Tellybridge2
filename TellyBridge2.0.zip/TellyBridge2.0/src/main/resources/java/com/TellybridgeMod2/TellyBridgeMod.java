package com.tellybridge;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.ClientCommandHandler;

@Mod(modid = "tellybridge", name = "Telly Bridge Mod", version = "2.0.0")
public class TellyBridgeMod {

    public static TellyBridgeHandler handler = new TellyBridgeHandler();

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ClientCommandHandler.instance.registerCommand(new CommandBind());
        ClientCommandHandler.instance.registerCommand(new CommandDelay());
        ClientCommandHandler.instance.registerCommand(new CommandSpeed());
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(handler);
    }
}