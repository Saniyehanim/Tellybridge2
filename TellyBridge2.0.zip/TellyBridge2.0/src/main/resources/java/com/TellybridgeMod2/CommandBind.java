package com.tellybridge;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import org.lwjgl.input.Keyboard;

public class CommandBind extends CommandBase {
    @Override
    public String getCommandName() { return "bind"; }
    @Override
    public String getCommandUsage(ICommandSender sender) { return "/bind <tuş>"; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Kullanım: /bind <tuş>"));
            return;
        }
        int key = Keyboard.getKeyIndex(args[0].toUpperCase());
        if (key == Keyboard.KEY_NONE) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Geçersiz tuş!"));
            return;
        }
        TellyBridgeMod.handler.bindKey = key;
        sender.addChatMessage(new net.minecraft.util.ChatComponentText("Tuş bağlandı: " + args[0].toUpperCase()));
    }

    @Override
    public int getRequiredPermissionLevel() { return 0; }
}