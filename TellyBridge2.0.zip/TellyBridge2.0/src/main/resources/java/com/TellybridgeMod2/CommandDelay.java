package com.tellybridge;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;

public class CommandDelay extends CommandBase {
    @Override
    public String getCommandName() { return "delay"; }
    @Override
    public String getCommandUsage(ICommandSender sender) { return "/delay <saniye>"; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Kullanım: /delay <saniye>"));
            return;
        }
        try {
            int seconds = Integer.parseInt(args[0]);
            TellyBridgeMod.handler.delay = seconds * 1000;
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Delay ayarlandı: " + seconds + " sn"));
        } catch (NumberFormatException e) {
            sender.addChatMessage(new net.minecraft.util.ChatComponentText("Geçersiz sayı!"));
        }
    }

    @Override
    public int getRequiredPermissionLevel() { return 0; }
}